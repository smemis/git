<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://www.kraftthemes.com
 * @since      1.0.0
 *
 * @package    Kraft_Toolkit
 * @subpackage Kraft_Toolkit/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Kraft_Toolkit
 * @subpackage Kraft_Toolkit/public
 * @author     Kraft Themes <info@kraftthemes.com>
 */
class Kraft_Toolkit_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string $plugin_name       The name of the plugin.
	 * @param      string $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		$this->kraft_toolkit_definitions();

	}

	/**
	 * Method kraft_toolkit_definitions
	 *
	 * @return void
	 */
	public function kraft_toolkit_definitions() {

		if ( ! defined( 'KRAFT_TOOLKIT_PUBLIC_PATH' ) ) {
			define( 'KRAFT_TOOLKIT_PUBLIC_PATH', plugin_dir_path( __FILE__ ) );
		}

	}

	/**
	 * Method kraft_toolkit_acf_settings_path
	 *
	 * @param $path $path [explicite description].
	 *
	 * @return string
	 */
	public function kraft_toolkit_acf_settings_path( $path ) {

		$path = plugin_dir_path( __FILE__ ) . '/advanced-custom-fields-pro/';
		return $path;

	}

	/**
	 * Method kraft_toolkit_acf_settings_dir
	 *
	 * @param $dir $dir [explicite description].
	 *
	 * @return $dir
	 */
	public function kraft_toolkit_acf_settings_dir( $dir ) {

		$dir = plugin_dir_url( __FILE__ ) . '/advanced-custom-fields-pro/';
		return $dir;

	}


	/**
	 * Method kraft_toolkit_custom_fields
	 *
	 * @return void
	 */
	public function kraft_toolkit_custom_fields() {

		$folder       = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/custom-fields/';
		$customfields = glob( $folder . '*.php' );

		foreach ( $customfields as $customfield ) {
			include_once $customfield;
		}

	}

	/**
	 * Method remove_su_prefix
	 *
	 * @param $shortcodes $shortcodes [explicite description].
	 *
	 * @return $shortcodes
	 */
	public function remove_su_prefix( $shortcodes ) {
		// $shortcodes = array();
		// $shortcodes['heading'] = array();
		// unset($shortcodes['heading']);
		// var_dump($shortcodes);
		// die;

		update_option( 'su_option_prefix', '' );
		// update_option( 'su_option_prefix', 'kraft_toolkit_' );

		return $shortcodes;
	}


	/**
	 * Method groupsx
	 *
	 * @return array
	 */
	public function groupsx() {
		return array(
			'all'     => __( 'All', 'shortcodes-ultimate' ),
			'content' => __( 'Content', 'shortcodes-ultimate' ),
			'khuni'   => __( 'KHUNI', 'shortcodes-ultimate' ),
		);
	}


	/**
	 * Method kraft_toolkit_shortcodes
	 *
	 * @return void
	 */
	public function kraft_toolkit_shortcodes() {

		if ( ! function_exists( 'is_plugin_active' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		add_filter( 'su/data/shortcodes', array( $this, 'remove_su_prefix' ), 0, 1 );
		add_filter( 'su/data/groups', array( $this, 'groupsx' ), 0, 1 );

		$folder     = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/shortcodes/';
		$shortcodes = glob( $folder . '*.php' );

		foreach ( $shortcodes as $shortcode ) {
			$l  = pathinfo( $shortcode );
			$fn = $l['filename'];

			include_once $shortcode;

			add_shortcode( $fn, $fn );

			// Visual Composer
			if ( function_exists( 'vc_map' ) ) {
				if ( function_exists( $fn . '_vc' ) ) {
					add_action( 'init', $fn . '_vc' );
				}
			}

			// King Composer
			if ( is_plugin_active( 'kingcomposer/kingcomposer.php' ) ) {
				if ( function_exists( $fn . '_kc' ) ) {
					add_action( 'init', $fn . '_kc' );
				}
			}

			// Shortcode Ultimate
			if ( function_exists( 'register_' . $fn . '_shortcode' ) ) {
				add_filter( 'su/data/shortcodes', 'register_' . $fn . '_shortcode', 0, 1 );
			}
		}
		if ( class_exists( 'Su_Data' ) ) {
			// Clear popup cache
			delete_transient( 'su/generator/popup' );
			// Clear shortcodes settings cache
			foreach ( array_keys( (array) Su_Data::shortcodes() ) as $shortcode ) {
				delete_transient( 'su/generator/settings/' . $shortcode );
			}
		}
		add_filter( 'widget_text', 'shortcode_unautop' );
		add_filter( 'widget_text', 'do_shortcode', 20 );

	}

	/**
	 * Method kraft_toolkit_posttypes
	 *
	 * @return void
	 */
	public function kraft_toolkit_posttypes() {

		$folder     = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/post-types/';
		$post_types = glob( $folder . '*.php' );

		foreach ( $post_types as $post_type ) {
			$l  = pathinfo( $post_type );
			$fn = $l['filename'];

			include_once $post_type;

		}

	}


	/**
	 * Method kraft_toolkit_widgets
	 *
	 * @return void
	 */
	public function kraft_toolkit_widgets() {

		$folder  = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/widgets/';
		$widgets = glob( $folder . '*.php' );

		foreach ( $widgets as $widget ) {
			include_once $widget;
		}
	}

	/**
	 * Method kraft_toolkit_widgets_collection
	 *
	 * Site Origins Widgets.
	 *
	 * @param $folders $folders [explicite description].
	 *
	 * @return $folders
	 */
	public function kraft_toolkit_widgets_collection( $folders ) {
		$folders[] = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/widgets/';

		return $folders;
	}

	/**
	 * Method kraft_toolkit_active_widgets
	 *
	 * @param $active $active [explicite description].
	 *
	 * @return $active
	 */
	public function kraft_toolkit_active_widgets( $active ) {
		global $pagenow;

		$active['button']               = true;
		$active['contact']              = true;
		$active['cta']                  = true;
		$active['editor']               = true;
		$active['features']             = true;
		$active['google-map']           = true;
		$active['headline']             = true;
		$active['hero']                 = true;
		$active['icon']                 = true;
		$active['image']                = true;
		$active['image-grid']           = true;
		$active['layout-slider']        = true;
		$active['post-carousel']        = true;
		$active['price-table']          = true;
		$active['simple-masonry']       = true;
		$active['slider']               = true;
		$active['social-media-buttons'] = true;
		$active['taxonomy']             = true;
		$active['testimonial']          = true;
		$active['video']                = true;

		$folder  = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/widgets/';
		$widgets = glob( $folder . '*/*.php' );
		foreach ( $widgets as $widget ) {
			$l                        = pathinfo( $widget );
			$active[ $l['filename'] ] = true;
		}

		if ( ( $pagenow == 'widgets.php' ) ) {
			$active['button_widget_so']                = false;
			$active['kraft_toolkit_welcome_widget_so'] = false;
		}

		return $active;
	}

	/**
	 * Method kraft_toolkit_hide_widgets
	 *
	 * Site Origin SO unset widgets.
	 *
	 * @param $widgets $widgets [explicite description].
	 *
	 * @return $widgets
	 */
	public function kraft_toolkit_hide_widgets( $widgets ) {

		unset( $widgets['Button_Widget_WP'] );

		return $widgets;
	}




	/**
	 * Method kraft_toolkit_layouts
	 *
	 * @param $layouts $layouts [explicite description].
	 *
	 * @return $layouts
	 */
	public function kraft_toolkit_layouts( $layouts ) {

		// global $kc;

		$folder            = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/layouts/';
		$pre_build_layouts = glob( $folder . '*.php' );

		foreach ( $pre_build_layouts as $layout ) {

			$l  = pathinfo( $layout );
			$fn = $l['filename'];

			include $layout;

			$layouts[ $fn ] = wp_parse_args(
				array(
					'name'        => $data['name'],
					'description' => $data['description'],
				),
				unserialize( $data['value'] )
			);

			$data = array();

		}

		return $layouts;
	}

	/**
	 * Method kraft_toolkit_page_layouts_vc
	 *
	 * @return void
	 */
	public function kraft_toolkit_page_layouts_vc() {

		$folder            = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/layouts/';
		$pre_build_layouts = glob( $folder . '*.php' );
		foreach ( $pre_build_layouts as $layout ) {
			include $layout;

			if ( $data['name'] ) {
				vc_add_default_templates( $data );
				$data = array();
			}
		}
	}


	/**
	 * Method kraft_toolkit_page_layouts_kc
	 *
	 * @return void
	 */
	public function kraft_toolkit_page_layouts_kc() {

		$folder            = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/layouts/';
		$pre_build_layouts = glob( $folder . '*.php' );

		foreach ( $pre_build_layouts as $layout ) {
			include $layout;

			if ( $data['name'] ) {

				if ( ! get_page_by_title( $data['name'], 'OBJECT', 'kc-section' ) ) {
					wp_insert_post(
						array(
							'post_type'    => 'kc-section',
							'post_content' => $data['kc_data'],
							'post_title'   => $data['name'],
							'post_status'  => 'publish',
						)
					);
				}

				$data = array();
			}
		}

	}

	/**
	 * Method kraft_toolkit_page_layouts_el
	 *
	 * @return void
	 */
	public function kraft_toolkit_page_layouts_el() {

		$folder            = KRAFT_TOOLKIT_PUBLIC_PATH . 'partials/layouts/';
		$pre_build_layouts = glob( $folder . '*.php' );

		foreach ( $pre_build_layouts as $layout ) {
			include $layout;

			if ( $data['el_data'] ) {
				if ( ! get_page_by_title( $data['name'], 'OBJECT', 'elementor_library' ) ) {

					$template_id = wp_insert_post(
						array(
							'post_type'    => 'elementor_library',
							'post_content' => 'THIS IS ELEMENTOR',
							'post_title'   => $data['name'],
							'post_status'  => 'publish',
						)
					);

					add_post_meta( $template_id, '_elementor_data', $data['el_data'] );
					add_post_meta( $template_id, '_elementor_edit_mode', 'builder' );
					add_post_meta( $template_id, '_elementor_template_type', 'page' );
					add_post_meta( $template_id, '_elementor_version', $template_id );
				}
			}
		}

	}


	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Kraft_Toolkit_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Kraft_Toolkit_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/kraft-toolkit-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Kraft_Toolkit_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Kraft_Toolkit_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/kraft-toolkit-public.js', array( 'jquery' ), $this->version, false );

	}

}
