<?php

function smt_testimonials( $atts, $content = null ) {
	ob_start();
	?>
	<div class="testimonial-list wow fadeInUp" data-wow-delay="0.8s">
	<!-- START SINGLE TESTIMONIAL DESIGN AREA -->
	<?php
	$testimonial_query_args = array(
		'post_type'   => 'testimonial',
		'post_status' => 'publish'
	)
	?>
	<?php $testimonial_query = new WP_Query( $testimonial_query_args ); ?>
	<?php if ( $testimonial_query->have_posts() ) : ?>
		<?php while ( $testimonial_query->have_posts() ) : $testimonial_query->the_post(); ?>
			<div class="single-testimonial text-center">
				<h2><?php echo get_the_title() ?></h2>
				<p><?php echo get_the_excerpt() ?></p>
			</div>
		<?php endwhile; ?>
		<?php wp_reset_postdata(); ?>
	<?php else : ?>
		<p><?php _e( ' ', 'khuni2' ); ?></p>
	<?php endif; ?>
	</div><?php
	$render = ob_get_contents();
	ob_end_clean();

	return $render;
}


//KC
function smt_testimonials_kc() {
	global $kc;
	$kc->add_map(
		array(
			'smt_testimonials' => array(
				'name' => 'SMT Testimonials',
				'description' => __('Testimonials', 'khuni1x'),
				'icon' => 'fa-picture-o',
				//'is_container' => true,
				'category' => 'KHUNI',
				//'css_box'    => true,
				'params' => array(
				)
			)
		)
	);

}

//VC
function smt_testimonials_vc() {
	vc_map(array(
		"name" => __("SMT Testimonials", "khuni1x"),
		"base" => "smt_testimonials",
		"icon" => "icon-button",
		"class" => "button_extended",
		"category" => __("KHUNI", "khuni1x"),
		"description" => __("Insert Testimonials", "khuni1x"),
		"content_element" => true,
		"params" => array(
		),
	));
}

//SU
function register_smt_testimonials_shortcode( $shortcodes ) {
	// Add new shortcode
	$shortcodes['smt_testimonials'] = array(
		// Shortcode name
		'name'     => __( 'SMT Testimonials', 'khuni1x' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type' => 'single',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'KHUNI',
		// List of shortcode params (attributes)
		'atts'     => array(
		),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Social link', 'khuni1x' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'smt_testimonials'
	);

	return $shortcodes;
}
?>