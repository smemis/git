<?php 
function smt_social_link( $atts, $content = null ) {
	ob_start();
	extract(shortcode_atts(
		array(
			'link' => '',
			'icon' => '',
		),
		$atts
	));
?><li>
            <a href="<?php echo esc_url( $link ); ?>"><i class="<?php echo "fa ". $icon ?>"></i></a>
        </li><?php 
	$render = ob_get_contents();
	ob_end_clean();
	return $render;
}

//KC
function smt_social_link_kc() {
	global $kc;
	$kc->add_map(
		array(
			'smt_social_link' => array(
				'name' => 'SMT Social Link',
				'description' => __('Social Link', 'khuni1x'),
				'icon' => 'fa-picture-o',
				//'is_container' => true,
				'category' => 'KHUNI',
				//'css_box'    => true,
				'accept_parent'	=> 'smt_social_links',
				'params' => array(
					array(
						'name' => 'icon',
						'label' => 'Icon',
						'type' => 'Icon',
						'value' => __('Select Icon', 'khuni1x')
					),
					array(
						'name' => 'link',
						'label' => 'Link',
						'type' => 'text',
						'value' => __('Link', 'khuni1x'),
						'admin_label' => true
					),
				)
			)
		)
	);

}

//VC
function smt_social_link_vc() {
	vc_map(array(
		"name" => __("SMT Social Link", "khuni1x"),
		"base" => "smt_social_link",
		"icon" => "icon-button",
		"class" => "button_extended",
		"category" => __("KHUNI", "khuni1x"),
		"description" => __("Insert Social Link", "khuni1x"),
		"content_element" => true,
		"as_child" => array('only' => 'smt_social_links'),
		"params" => array(
			array(
				"param_name" => "icon",
				"type" => "textfield",
				"heading" => __("Icon", "khuni1x"),
				"description" => __("Select Icon", "khuni1x")
			),
			array(
				"param_name" => "link",
				"type" => "textfield",
				"heading" => __("Link", "khuni1x"),
				"description" => __("Link", "khuni1x"),
				"admin_label" => true
			),
		),
	));
}
/*if ( class_exists( 'WPBakeryShortCode' ) ) {
	class WPBakeryShortCode_Smt_Social_Link  extends WPBakeryShortCode {
	}
}*/

//SU
function register_smt_social_link_shortcode( $shortcodes ) {
	// Add new shortcode
	$shortcodes['smt_social_link'] = array(
		// Shortcode name
		'name'     => __( 'SMT Social Link', 'khuni1x' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type'     => 'wrap',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'KHUNI',
		// List of shortcode params (attributes)
		'atts'     => array(
			'icon' => array(
				'type' => 'text',
				'name' => 'Icon',
				'desc' => ''
			),
			'link' => array(
				'type' => 'text',
				'name' => 'Link',
				'desc' => ''
			)
		),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Social link', 'khuni1x' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'smt_social_link'
	);

	return $shortcodes;
}
?>