<?php
function smt_button( $atts, $content = null ) {
	ob_start();
	extract(shortcode_atts(
		array(
			'type' => 'black',
			'link' => '#',
			'text' => 'View More',
			'target' => '_self',
		),
		$atts
	));
?><a target="<?php echo $target ?>" class="smoth-scroll wow fadeInUp <?php echo $type."-btn" ?>" data-wow-delay="1.2s" href="<?php echo esc_url( $link ); ?>"><?php echo $text ?></a><?php
	$render = ob_get_contents();
	ob_end_clean();
	return $render;
}

//VC
function smt_button_vc() {

	vc_map(array(
		"name" => __("SMT Button", "khuni1x"),
		"base" => "smt_button",
		"icon" => "icon-button",
		"class" => "button_extended",
		"category" => __("KHUNI", "khuni1x"),
		"description" => __("Insert Button", "khuni1x"),
		"params" => array(
			array(
				"param_name" => "type",
				"type" => "dropdown",
				"heading" => __("Type", "khuni1x"),
				"value" => array(
					__("Black", "khuni1x") => "black",
					__("White", "khuni1x") => "white"
				),
				"description" => __("Select button type.", "khuni1x")
			),
			array(
				"param_name" => "link",
				"type" => "textfield",
				"heading" => __("Link", "khuni1x"),
				"description" => __("The URL to which button should point to. The user is taken to this destination when the button is clicked.eg.http://targeturl.com", "khuni1x")
			),
			array(
				"param_name" => "target",
				"type" => "dropdown",
				"heading" => __("Target", "khuni1x"),
				"value" => array(
					__("Open link in the same window", "khuni1x") => "_self",
					__("Open link in new window", "khuni1x") => "_blank"
				),
				"description" => __("_self = open in same window. _blank = open in new window", "khuni1x")
			),
			array(
				"param_name" => "text",
				"type" => "textfield",
				"admin_label" => true,
				"heading" => __("Text", "khuni1x"),
				"description" => __("Specify the text of the button.", "khuni1x")
			)
		),
		"show_settings_on_create" => true
	));

}

//KC
function smt_button_kc(){

	global $kc;
	$kc->add_map(
		array(
			'smt_button' => array(
				'name' => 'SMT Button',
				'description' => __('Insert Button', 'khuni1x'),
				'icon' => 'fa-picture-o',
				//'is_container' => true,
				'category' => 'KHUNI',
				//'css_box'    => true,

				'params' => array(
					array(
						'name' => 'type',
						'label' => 'Type',
						'type' => 'text',
						'value' => __('type here', 'khuni1x')
					),
					array(
						'name' => 'link',
						'label' => 'Link',
						'type' => 'text',
						'value' => __('link here', 'khuni1x')
					),
					array(
						'name' => 'target',
						'label' => 'Target',
						'type' => 'text',
						'value' => __('target here', 'khuni1x')
					),
					array(
						'name' => 'text',
						'label' => 'Text',
						'type' => 'text',
						'value' => __('text here', 'khuni1x')
					),
				)
			)
		)
	);


}

//SU
function register_smt_button_shortcode( $shortcodes ) {


	// Add new shortcode
	$shortcodes['smt_button'] = array(
		// Shortcode name
		'name'     => __( 'SMT Button', 'khuni1x' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type'     => 'wrap',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'KHUNI',
		// List of shortcode params (attributes)
		'atts'     => array(
			'type' => array(
				'type' => 'text',
				'name' => 'Type',
				'desc' => 'Button Type'
			),
			'link' => array(
				'type' => 'text',
				'name' => 'Link',
				'desc' => 'Button Link'
			),
			'text' => array(
				'type' => 'text',
				'name' => 'Text',
				'desc' => 'Button Text'
			),
			'target' => array(
				'type' => 'text',
				'name' => 'Target',
				'desc' => 'Button Target'
			)
		),
		// Default content for generator (for wrap-type shortcodes)
		'content'  => __( 'View More', 'khuni1x' ),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Custom Button', 'khuni1x' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'smt_button'
	);

	return $shortcodes;
}

?>