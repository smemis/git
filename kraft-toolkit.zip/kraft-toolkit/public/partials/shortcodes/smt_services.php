<?php
function smt_services( $atts, $content = null ) {
	ob_start();
?><div class="row">
            <!-- START SINGLE SERVICE DESIGN AREA -->
            <?php
                $services_query_args = array(
                    'post_type' => 'service',
                    'post_status' => 'publish'
                )
            ?>
            <?php $services_query = new WP_Query( $services_query_args ); ?>
            <?php if ( $services_query->have_posts() ) : ?>
                <?php while ( $services_query->have_posts() ) : $services_query->the_post(); ?>
                    <div class="col-md-4">
                        <?php 
$icon = get_field("icon");
$title = get_the_title();
$text = get_the_excerpt();

//echo do_shortcode('[icon_box icon="' . $icon . '" title="' . $title . '"]' . $text . '[/icon_box]');

$atts = array(
'icon' => $icon,
'title' => $title,
'content' => $text,
);

echo smt_icon_box($atts);

?>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
            <?php else : ?>
                <p><?php _e( ' ', 'khuni2' ); ?></p>
            <?php endif; ?>
        </div><?php
	$render = ob_get_contents();
	ob_end_clean();
	return $render;
}



//KC
function smt_services_kc() {
	global $kc;
	$kc->add_map(
		array(

			'smt_services' => array(
				'name' => 'SMT Services',
				'description' => __('Services', 'khuni1x'),
				'icon' => 'fa-picture-o',
				//'is_container' => true,
				'category' => 'KHUNI',
				//'css_box'    => true,

				'params' => array(
				)
			)
		)
	);

}

//VC
function smt_services_vc() {
	vc_map(array(
		"name" => __("SMT Services", "khuni1x"),
		"base" => "smt_services",
		"icon" => "icon-button",
		"class" => "button_extended",
		"category" => __("KHUNI", "khuni1x"),
		"description" => __("Insert Services", "khuni1x"),
		"params" => array(
		),
		"show_settings_on_create" => true
	));
}

//SU
function register_smt_services_shortcode( $shortcodes ) {
	// Add new shortcode
	$shortcodes['smt_services'] = array(
		// Shortcode name
		'name'     => __( 'SMT Services', 'khuni1x' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type'     => 'single',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'KHUNI',
		// List of shortcode params (attributes)
		'atts'     => array(
		),
		// Default content for generator (for wrap-type shortcodes)
		'content'  => __( 'Lorem Ipsum', 'khuni1x' ),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Icon box', 'khuni1x' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'smt_services'
	);

	return $shortcodes;
}
?>