<?php
function smt_icon_box( $atts, $content = null ) {
	ob_start();
	extract(shortcode_atts(
		array(
			'icon' => '',
			'title' => '',
			'content' => '',
		),
		$atts
	));
?><div class="wow fadeInUp icon-box" data-wow-delay="0.4s">
            <i class="<?php echo "fa ".$icon ?>"></i>
            <h2><?php echo $title ?></h2>
            <p><?php echo $content ?></p>
        </div><?php
	$render = ob_get_contents();
	ob_end_clean();
	return $render;
}

//KC
function smt_icon_box_kc() {
	global $kc;
	$kc->add_map(
		array(
			'smt_icon_box' => array(
				'name' => 'SMT Icon Box',
				'description' => __('Icon Box', 'khuni1x'),
				'icon' => 'fa-picture-o',
				//'is_container' => true,
				'category' => 'KHUNI',
				//'css_box'    => true,
				'params' => array(
					array(
						'name' => 'icon',
						'label' => 'Type',
						'type' => 'Icon',
						'value' => __('Icon', 'khuni1x')
					),
					array(
						'name' => 'title',
						'label' => 'title',
						'type' => 'text',
						'value' => __('Title', 'khuni1x')
					),
					array(
						'name' => 'content',
						'label' => 'content',
						'type' => 'text',
						'value' => __('Lorem Ipsum', 'khuni1x')
					),
				)
			)
		)
	);

}

//VC
function smt_icon_box_vc() {
	vc_map(array(
		"name" => __("SMT Icon Box", "khuni1x"),
		"base" => "smt_icon_box",
		"icon" => "icon-button",
		"class" => "button_extended",
		"category" => __("KHUNI", "khuni1x"),
		"description" => __("Insert Icon Box", "khuni1x"),
		"params" => array(
			array(
				"param_name" => "icon",
				"type" => "textfield",
				"heading" => __("Icon", "khuni1x"),
				"description" => __("Select Icon.", "khuni1x")
			),
			array(
				"param_name" => "title",
				"type" => "textfield",
				"heading" => __("Title", "khuni1x"),
				"description" => __("Icon Box Title", "khuni1x")
			),
			array(
				"param_name" => "content",
				"type" => "textfield",
				"heading" => __("Content", "khuni1x"),
				"description" => __("Icon Box Content", "khuni1x")
			),
		),
		"show_settings_on_create" => true
	));
}

//SU
function register_smt_icon_box_shortcode( $shortcodes ) {
	// Add new shortcode
	$shortcodes['smt_icon_box'] = array(
		// Shortcode name
		'name'     => __( 'SMT Icon Box', 'khuni1x' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type'     => 'wrap',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'KHUNI',
		// List of shortcode params (attributes)
		'atts'     => array(
			'icon' => array(
				'type' => 'text',
				'name' => 'Icon',
				'desc' => ''
			),
			'title' => array(
				'type' => 'text',
				'name' => 'Title',
				'desc' => ''
			)
		),
		// Default content for generator (for wrap-type shortcodes)
		'content'  => __( 'Lorem Ipsum', 'khuni1x' ),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Icon box', 'khuni1x' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'smt_icon_box'
	);

	return $shortcodes;
}

?>