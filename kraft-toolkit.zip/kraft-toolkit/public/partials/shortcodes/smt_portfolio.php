<?php
function smt_portfolio( $atts, $content = null ) {
	ob_start();
?><div class="container">
            <div class="row">
                <ul class="work">
                    <li class="filter" data-filter="all">
                        <?php _e( 'all', 'khuni2' ); ?>
                    </li>
                    <?php 
$terms = get_terms( 'portfolio-type' );
foreach ( $terms as $term ){
?>
                        <li class="filter" data-filter="<?php echo '.'.$term->slug; ?>">
	                        <?php echo $term->name; ?>
                        </li>
                    <?php
}
?>
                </ul>
            </div>
            <div class="work-inner">
                <div class="row work-posts">
                    <!-- START SINGLE WORK DESIGN AREA -->
                    <?php
                        $portfolio_query_args = array(
                            'post_type' => 'portfolio',
                            'post_status' => 'publish'
                        )
                    ?>
                    <?php $portfolio_query = new WP_Query( $portfolio_query_args ); ?>
                    <?php if ( $portfolio_query->have_posts() ) : ?>
                        <?php while ( $portfolio_query->have_posts() ) : $portfolio_query->the_post(); ?>
                            <div class="<?php
                            /*                            $category_classes = '';
														$categories = get_terms($post->ID, 'portfolio-type');
														foreach($categories as $category){
															$category_classes .= ' '.$category->slug;
														};
							*/
                            $xterms = get_the_terms($post->ID,'portfolio-type');
                            $xslugs = "";
                            if( $xterms != null){
	                            foreach($xterms as $term){
		                            $xslugs .= $term->slug . ' ';
		                            unset($term);
	                            }
                            }
                            echo('col-md-4 col-sm-4 mix '. $xslugs); ?>">
                                <div class="item wow fadeInUp" data-wow-delay="0.2s">
                                    <a href="<?php $portfolio_big = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'portfolio-big' ); echo ($portfolio_big[0]); ?>" class="work-popup">
                                        <img src="<?php $portfolio_thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'portfolio-thumb' ); echo ($portfolio_thumb[0]); ?>" alt="">
                                    </a>
                                </div>
                            </div>
                        <?php endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'khuni2' ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div><?php
	$render = ob_get_contents();
	ob_end_clean();
	return $render;
}


//KC
function smt_portfolio_kc() {
	global $kc;
	$kc->add_map(
		array(
			'smt_portfolio' => array(
				'name' => 'SMT Portfolio',
				'description' => __('Portfolio', 'khuni1x'),
				'icon' => 'fa-picture-o',
				//'is_container' => true,
				'category' => 'KHUNI',
				//'css_box'    => true,
				'params' => array(
				)
			)
		)
	);

}

//VC
function smt_portfolio_vc() {
	vc_map(array(
		"name" => __("SMT Portfolio", "khuni1x"),
		"base" => "smt_portfolio",
		"icon" => "icon-button",
		"class" => "button_extended",
		"category" => __("KHUNI", "khuni1x"),
		"description" => __("Portfolio", "khuni1x"),
		"content_element" => true,
		"params" => array(
		),
	));
}

//SU
function register_smt_portfolio_shortcode( $shortcodes ) {
	// Add new shortcode
	$shortcodes['smt_portfolio'] = array(
		// Shortcode name
		'name'     => __( 'SMT Portfolio', 'khuni1x' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type' => 'single',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'KHUNI',
		// List of shortcode params (attributes)
		'atts'     => array(
		),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Portfolio', 'khuni1x' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'smt_portfolio'
	);

	return $shortcodes;
}
?>