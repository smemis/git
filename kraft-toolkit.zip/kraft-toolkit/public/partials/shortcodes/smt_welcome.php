<?php
function smt_welcome( $atts, $content = null ) {
	ob_start();
	extract(shortcode_atts(
		array(
			'url' => '',
			'text1' => '',
			'text2' => '',
			'link' => '',
			'link_text' => '',
		),
		$atts
	));
    $url = "background-image:url(".$url.");";
?><div class="welcome-image-area" data-stellar-background-ratio="0.6" style="<?php echo $url ?>">
            <div class="display-table">
                <div class="display-table-cell">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <div class="header-text">
                                    <p class="wow fadeInUp" data-wow-delay="0.4s"><?php echo $text1 ?></p>
                                    <h2 class="wow fadeInUp" data-wow-delay="0.8s"><?php echo $text2 ?></h2>
                                    <a class="home-btn smoth-scroll wow fadeInUp" data-wow-delay="1.2s" href="<?php echo esc_url( $link ); ?>"><?php echo $link_text ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><?php
	$render = ob_get_contents();
	ob_end_clean();
	return $render;
}


//VC
function smt_welcome_vc() {

	vc_map(array(
		"name" => __("SMT Welcome", "khuni1x"),
		"base" => "smt_welcome",
		"icon" => "icon-button",
		"class" => "button_extended",
		"category" => __("KHUNI", "khuni1x"),
		"description" => __("Insert Welcome", "khuni1x"),
		"params" => array(
			array(
				"param_name" => "url",
				"type" => "textfield",
				"heading" => __("Background URL", "khuni1x"),
				"description" => __("Background URL", "khuni1x")
			),
			array(
				"param_name" => "text1",
				"type" => "textfield",
				"heading" => __("Text 1", "khuni1x"),
				"description" => __("Text 1", "khuni1x")
			),
			array(
				"param_name" => "text2",
				"type" => "textfield",
				"heading" => __("Text 2", "khuni1x"),
				"description" => __("Text 3", "khuni1x")
			),
			array(
				"param_name" => "link",
				"type" => "textfield",
				"heading" => __("Link", "khuni1x"),
				"description" => __("The URL to which button should point to. The user is taken to this destination when the button is clicked.eg.http://targeturl.com", "khuni1x")
			),
			array(
				"param_name" => "link_text",
				"type" => "textfield",
				"heading" => __("Link Text", "khuni1x"),
				"description" => __("Link Text", "khuni1x")
			),
		),
		"show_settings_on_create" => true
	));

}

//KC
function smt_welcome_kc(){
	global $kc;
	$kc->add_map(
		array(
			'smt_welcome' => array(
				'name' => 'SMT Welcome',
				'description' => __('Display Button', 'khuni1x'),
				'icon' => 'fa-picture-o',
				//'is_container' => true,
				'category' => 'KHUNI',
				//'css_box'    => true,
				'params' => array(
					array(
						'name' => 'url',
						'label' => 'Type',
						'type' => 'Background URL',
						'value' => __('', 'khuni1x')
					),
					array(
						'name' => 'text1',
						'label' => 'Text 1',
						'type' => 'text',
						'value' => __('', 'khuni1x')
					),
					array(
						'name' => 'text2',
						'label' => 'Text 2',
						'type' => 'text',
						'value' => __('', 'khuni1x')
					),
					array(
						'name' => 'link',
						'label' => 'Link',
						'type' => 'text',
						'value' => __('', 'khuni1x')
					),
					array(
						'name' => 'link_text',
						'label' => 'Link Text',
						'type' => 'text',
						'value' => __('', 'khuni1x')
					),
				)
			)
		)
	);


}

//SU
function register_smt_welcome_shortcode( $shortcodes ) {
	// Add new shortcode
	$shortcodes['smt_welcome'] = array(
		// Shortcode name
		'name'     => __( 'SMT Welcome', 'khuni1x' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type'     => 'wrap',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'KHUNI',
		// List of shortcode params (attributes)
		'atts'     => array(
			'url' => array(
				'type' => 'text',
				'name' => 'Background URL',
				'desc' => ''
			),
			'text1' => array(
				'type' => 'text',
				'name' => 'Text 1',
				'desc' => ''
			),
			'text2' => array(
				'type' => 'text',
				'name' => 'Text 2',
				'desc' => ''
			),
			'link' => array(
				'type' => 'text',
				'name' => 'Link',
				'desc' => ''
			),
			'link_text' => array(
				'type' => 'text',
				'name' => 'Link Text',
				'desc' => ''
			)
		),
		// Default content for generator (for wrap-type shortcodes)
		'content'  => __( '', 'khuni1x' ),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Custom Welcome', 'khuni1x' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'smt_welcome'
	);

	return $shortcodes;
}


?>