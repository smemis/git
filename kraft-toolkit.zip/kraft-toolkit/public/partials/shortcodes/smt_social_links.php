<?php
function smt_social_links( $atts, $content = null ) {
	ob_start();
?><div class="social-links text-center">
            <ul>
                <?php
echo do_shortcode($content);
?>
            </ul>
        </div><?php
	$render = ob_get_contents();
	ob_end_clean();
	return $render;
}

//KC
function smt_social_links_kc() {
	global $kc;
	$kc->add_map(
		array(
			'smt_social_links' => array(
				'name' => 'SMT Social Links',
				'description' => __('Social Links', 'khuni1x'),
				'icon' => 'fa-picture-o',
				'is_container' => true,
				'category' => 'KHUNI',
				//'css_box'    => true,
				'nested'		=> true,
				'accept_child'	=> 'smt_social_link',
				'params' => array(
				)
			)
		)
	);
}

//VC
function smt_social_links_vc() {
	vc_map(array(
		"name" => __("SMT Social Links", "khuni1x"),
		"base" => "smt_social_links",
		"icon" => "icon-button",
		"class" => "button_extended",
		"category" => __("KHUNI", "khuni1x"),
		"description" => __("Insert Social Links", "khuni1x"),
		"as_parent" => array('only' => 'smt_social_link'),
		"params" => array(
		),
		"show_settings_on_create" => false,
		"js_view" => "VcColumnView"
	));
}
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_Smt_Social_Links extends WPBakeryShortCodesContainer {
	}
}

//SU
function register_smt_social_links_shortcode( $shortcodes ) {
	// Add new shortcode
	$shortcodes['smt_social_links'] = array(
		// Shortcode name
		'name'     => __( 'SMT Social Links', 'khuni1x' ),
		// Shortcode type. Can be 'wrap' or 'single'
		// Example: [b]this is wrapped[/b], [this_is_single]
		'type'     => 'wrap',
		// Shortcode group.
		// Can be 'content', 'box', 'media' or 'other'.
		// Groups can be mixed, for example 'content box'
		'group'    => 'KHUNI',
		// List of shortcode params (attributes)
		'atts'     => array(
		),
		// Shortcode description for cheatsheet and generator
		'desc'     => __( 'Social links', 'khuni1x' ),
		// Custom icon (font-awesome)
		'icon'     => 'plus',
		// Name of custom shortcode function
		'function' => 'smt_social_links'
	);

	return $shortcodes;
}
?>