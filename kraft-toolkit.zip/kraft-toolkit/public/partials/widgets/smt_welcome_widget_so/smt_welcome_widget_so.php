<?php
/*
Widget Name: Button
Description: Renders a button with multiple styles.
Author: SM Themes
Author URI: http://portfoliotheme.org
*/

class SMT_Welcome_Widget_SO extends SiteOrigin_Widget {

    function __construct() {
        //Here you can do any preparation required before calling the parent constructor, such as including additional files or initializing variables.

        //Call the parent constructor with the required arguments.
        parent::__construct(
            "smt_welcome_widget_so",
            __("Welcome", "khuni1x"),
            array(
                "description" => __("SMT Renders a Welcome..", "khuni1x"),
                "panels_icon" => "dashicons dashicons-minus",
            ),
            array(),
            array(
                "widget_title" => array(
                    "type" => "text",
                    "label" => __("Title", "khuni1x"),
                ),
                "url" => array(
	                "type" => "text",
	                "description" => __("Background URL", "khuni1x"),
	                "label" => __("Type", "khuni1x"),
	                "default" => __("http://tanvirrahmanhridoy.xyz/tf/khuni-demo/assets/images/bg/bg.jpg", "khuni1x"),
                ),
                "text1" => array(
	                "type" => "text",
	                "description" => __("Text 1", "khuni1x"),
	                "label" => __("Text 1", "khuni1x"),
	                "default" => __("HI! THIS IS JOHN DOE", "khuni1x"),
                ),
                "text2" => array(
	                "type" => "text",
	                "description" => __("Text 2", "khuni1x"),
	                "label" => __("Text 2", "khuni1x"),
	                "default" => __("A Professional Web designer.", "khuni1x"),
                ),
                "link" => array(
	                "type" => "text",
	                "description" => __("Link. ", "khuni1x"),
	                "label" => __("Link", "khuni1x"),
	                "default" => __("#", "khuni1x"),
                ),
                "link_text" => array(
	                "type" => "text",
	                "description" => __("Link text", "khuni1x"),
	                "label" => __("Link", "khuni1x"),
	                "default" => __("View Works", "khuni1x"),
                ),
            )
        );

        add_action( 'admin_head', array(&$this,'admin_inline_js' ));

    }

    function admin_inline_js(){
        ?>
        <script type="text/javascript">
            (function($) {
                $(document).ready(function () {
//						alert(1);
                    $("[id*='<?php echo '-smt_welcome-widget-';?>']").remove();
                });
            })(jQuery);
        </script>
        <?php
    }

    function get_style_name($instance) {
        return '';
    }

    function get_template_name($instance) {
        return 'view';
    }

    function get_template_dir($instance) {
        return 'template';
    }


    function get_template_variables($instance, $args) {
//        var_dump($args);
//        die;
        return array(
            "url" => $instance["url"],
            "text1" => $instance["text1"],
            "text2" => $instance["text2"],
            "link" => (!empty($instance['link'])) ? sow_esc_url($instance['link']) : '',
            "link_text" => $instance['link_text'],
        );
    }


}

siteorigin_widget_register('smt_welcome_widget_so', __FILE__, 'SMT_Welcome_Widget_SO');

