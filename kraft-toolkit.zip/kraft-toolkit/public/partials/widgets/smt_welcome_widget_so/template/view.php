<?php
/**
 * @var $type
 * @var $link
 * @var $target
 * @var $text
 */
$atts = array(
	'url' => $url,
	'text1' => $text1,
	'text2' => $text2,
	'link' => $link,
	'link_text' => $link_text,
);

echo smt_welcome($atts);
