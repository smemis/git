<?php
/**
 * @var $type
 * @var $link
 * @var $target
 * @var $text
 */
$atts = array(
);

echo smt_portfolio($atts);
