<?php
/*
Widget Name: SMT Portfolio
Description: Renders a Portfolio.
Author: SM Themes
Author URI: http://portfoliotheme.org
*/

class SMT_Portfolio_Widget_SO extends SiteOrigin_Widget {

    function __construct() {
        //Here you can do any preparation required before calling the parent constructor, such as including additional files or initializing variables.

        //Call the parent constructor with the required arguments.
        parent::__construct(
            "smt_portfolio_widget_so",
            __("Portfolio", "khuni1x"),
            array(
                "description" => __("SMT Portfolio", "khuni1x"),
                "panels_icon" => "dashicons dashicons-minus",
            ),
            array(),
            array(
            )
        );

        add_action( 'admin_head', array(&$this,'admin_inline_js' ));

    }

    function admin_inline_js(){
        ?>
        <script type="text/javascript">
            (function($) {
                $(document).ready(function () {
//						alert(1);
                    $("[id*='<?php echo '-smt_portfolio-widget-';?>']").remove();
                });
            })(jQuery);
        </script>
        <?php
    }

    function get_style_name($instance) {
        return '';
    }

    function get_template_name($instance) {
        return 'view';
    }

    function get_template_dir($instance) {
        return 'template';
    }


    function get_template_variables($instance, $args) {
        return array(
        );
    }


}

siteorigin_widget_register('smt_portfolio_widget_so', __FILE__, 'SMT_Portfolio_Widget_SO');

