<?php
/*
Widget Name: SMT Button
Description: Renders a button with multiple styles.
Author: SM Themes
Author URI: http://portfoliotheme.org
*/

class SMT_Button_Widget_SO extends SiteOrigin_Widget {

    function __construct() {
        //Here you can do any preparation required before calling the parent constructor, such as including additional files or initializing variables.

        //Call the parent constructor with the required arguments.
        parent::__construct(
            "smt_button_widget_so",
            __("SMT Button SO", "khuni1x"),
            array(
                "description" => __("SMT Button", "khuni1x"),
                "panels_icon" => "dashicons dashicons-minus",
            ),
            array(),
            array(
                "type" => array(
	                "type" => "text",
	                "description" => __("Type", "khuni1x"),
	                "label" => __("Type", "khuni1x"),
	                "default" => __("black", "khuni1x"),
                ),
                "link" => array(
	                "type" => "text",
	                "description" => __("Link", "khuni1x"),
	                "label" => __("Link", "khuni1x"),
	                "default" => __("", "khuni1x"),
                ),
                "text" => array(
	                "type" => "text",
	                "description" => __("Text", "khuni1x"),
	                "label" => __("Text", "khuni1x"),
	                "default" => __("", "khuni1x"),
                ),
                "target" => array(
	                "type" => "text",
	                "description" => __("Target", "khuni1x"),
	                "label" => __("target", "khuni1x"),
	                "default" => __("_self", "khuni1x"),
                ),
            )
        );

        add_action( 'admin_head', array(&$this,'admin_inline_js' ));

    }

    function admin_inline_js(){
        ?>
        <script type="text/javascript">
            (function($) {
                $(document).ready(function () {
//						alert(1);
                    $("[id*='<?php echo '-smt_button-widget-';?>']").remove();
                });
            })(jQuery);
        </script>
        <?php
    }

    function get_style_name($instance) {
        return '';
    }

    function get_template_name($instance) {
        return 'view';
    }

    function get_template_dir($instance) {
        return 'template';
    }


    function get_template_variables($instance, $args) {
        return array(
            "type" => $instance["type"],
            "link" => $instance["link"],
            "text" => $instance["text"],
            "target" => $instance['target'],
        );
    }


}

siteorigin_widget_register('smt_button_widget_so', __FILE__, 'SMT_Button_Widget_SO');

