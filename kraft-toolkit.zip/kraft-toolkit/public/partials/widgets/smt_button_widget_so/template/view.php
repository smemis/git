<?php
/**
 * @var $type
 * @var $link
 * @var $target
 * @var $text
 */
$atts = array(
	'type' => $type,
	'link' => $link,
	'text' => $text,
	'target' => $target,
);

echo smt_button($atts);
