<?php
/**
 * @var $type
 * @var $link
 * @var $target
 * @var $text
 */

$content = "";
foreach( $links as $link ) {
	$atts = array(
		'icon' => $link['icon'],
		'link' => $link['link']
	);
	$content .= smt_social_link( $atts );
}
echo smt_social_links( null, $content );
