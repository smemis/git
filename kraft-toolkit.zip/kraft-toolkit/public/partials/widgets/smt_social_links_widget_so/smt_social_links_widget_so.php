<?php
/*
Widget Name: SMT Social Links
Description: Renders a Social_Links.
Author: SM Themes
Author URI: http://social_linkstheme.org
*/

class SMT_Social_Links_Widget_SO extends SiteOrigin_Widget {

    function __construct() {
        //Here you can do any preparation required before calling the parent constructor, such as including additional files or initializing variables.

        //Call the parent constructor with the required arguments.
        parent::__construct(
            "smt_social_links_widget_so",
            __("Social Links", "khuni1x"),
            array(
                "description" => __("SMT Social Links", "khuni1x"),
                "panels_icon" => "dashicons dashicons-minus",
            ),
            array(),
            array(
	            'links' => array(
		            'type' => 'repeater',
		            'label' => __('Social Links', 'khuni1x'),
		            'item_name' => __('Social Link', 'khuni1x'),
		            'item_label' => array(
			            'selector' => "[id*='links-link']",
			            'update_event' => 'change',
			            'value_method' => 'val'
		            ),
		            'fields' => array(
			            'icon' => array(
				            'type' => 'text',
				            'label' => __('Icon', 'khuni1x'),
			            ),
			            'link' => array(
				            'type' => 'text',
				            'label' => __('Link', 'so-widgets-bundle'),
			            ),
		            ),
	            ),
            )
        );

        add_action( 'admin_head', array(&$this,'admin_inline_js' ));

    }

    function admin_inline_js(){
        ?>
        <script type="text/javascript">
            (function($) {
                $(document).ready(function () {
//						alert(1);
                    $("[id*='<?php echo '-smt_social_links-widget-';?>']").remove();
                });
            })(jQuery);
        </script>
        <?php
    }

    function get_style_name($instance) {
        return '';
    }

    function get_template_name($instance) {
        return 'view';
    }

    function get_template_dir($instance) {
        return 'template';
    }


    function get_template_variables($instance, $args) {
        return array(
	        "links" => $instance["links"],
        );
    }


}

siteorigin_widget_register('smt_social_links_widget_so', __FILE__, 'SMT_Social_Links_Widget_SO');

