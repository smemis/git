<?php
/**
 * @var $type
 * @var $link
 * @var $target
 * @var $text
 */
$atts = array(
	'icon' => $icon,
	'title' => $title,
	'content' => $content,
);

echo smt_icon_box($atts);
